<?php
session_start(); 
include("config.inc.php"); 
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Membuat Shopping Cart Dengan PHP,Ajax,JQuery & Bootstrap</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="style/style.css" rel="stylesheet" type="text/css">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">AndezShop</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Service</a>
                    </li>
					<li>
                        <a href="#">Colection</a>
                    </li>
					<li>
                        <a href="#">Contact</a>
                    </li>
					
					<li>
                        <a href="#"></a>
                    </li>
					
					<li>
                        <a href="#"></a>
                    </li>

					<li>
                <a href="#" class="cart-box" id="cart-info" title="View Cart">
				<?php 
				if(isset($_SESSION["products"])){
				echo count($_SESSION["products"]); 
				}else{
				echo 0; 
				}
				?>
				</a>
                    </li>
					
					
                </ul>
				

            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		<div class="shopping-cart-box">
			<a href="#" class="close-shopping-cart-box" >Close</a>
			<h3>Keranjang Belanja Anda</h3>
			<div id="shopping-cart-results">
			</div>
		</div>
		
    </nav>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <div class="col-md-3">
               
                <div class="list-group">
                    <a href="index.php" class="list-group-item">Baju Muslim</a>
                    <a href="#" class="list-group-item">Baju Couple</a>
                    <a href="#" class="list-group-item">Baju Wanita</a>
                </div>
				
				
				
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- iklan 300x600 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:600px"
     data-ad-client="ca-pub-7891974726842566"
     data-ad-slot="9898962334"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
            </div>

            <div class="col-md-9">

                <div class="row carousel-holder">

                   

                </div>

                <div class="row">

                    <div align="center">
<h3>Baju Murah AndezShop</h3>
</div>
<?php
//List produk dari database
$results = $mysqli_conn->query("SELECT nama_produk, deskripsi_produk, code_produk, image_produk, price_produk FROM tbl_produk");

$products_list =  '<ul class="products-wrp">';
$fn = 'convert_to_rupiah'; // mengambil fungsi rupiah

while($row = $results->fetch_assoc()) {
$products_list .= <<<EOT
<li>
<form class="form-item">
<h4>{$row["nama_produk"]}</h4>
<div><img src="images/{$row["image_produk"]}"></div>
<div>Harga :{$fn($row["price_produk"])}<div>
<div class="item-box">
    <div>
	Warna :
    <select name="product_color">
    <option value="Merah">Merah</option>
    <option value="Biru">Biru</option>
    <option value="Kuning">Kuning</option>
    </select>
	</div>
	
	<div>
    Qty :
    <select name="product_qty">
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    </select>
	</div>
	
	<div>
    Ukuran :
    <select name="product_size">
	<option value="M">M</option>
    <option value="XL">XL</option>
    <option value="XXL">XLL</option>
    </select>
	</div>
	
    <input name="product_code" type="hidden" value="{$row["code_produk"]}">
    <button type="submit">BELI</button>
</div>
</form>
</li>
EOT;

}
$products_list .= '</ul></div>';

echo $products_list;
?>

                </div>

            </div>

        </div>

    </div>
    <!-- /.container -->

    <div class="container">

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; andeznet.com 2015</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
   <script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
<script>
$(document).ready(function(){	
		$(".form-item").submit(function(e){
			var form_data = $(this).serialize();
			var button_content = $(this).find('button[type=submit]');
			button_content.html('Adding...'); //Loading button text 

			$.ajax({ //request ajax ke cart_process.php
				url: "cart_process.php",
				type: "POST",
				dataType:"json", 
				data: form_data
			}).done(function(data){ //Jika Ajax berhasil
				$("#cart-info").html(data.items); //total items di cart-info element
				button_content.html('BELI'); //
				alert("Item telah dimasukan ke keranjang belanja anda"); 
				if($(".shopping-cart-box").css("display") == "block"){
					$(".cart-box").trigger( "click" ); 
				}
			})
			e.preventDefault();
		});

	//menampilkan item ke keranjang belanja
	$( ".cart-box").click(function(e) { 
		e.preventDefault(); 
		$(".shopping-cart-box").fadeIn(); 
		$("#shopping-cart-results").html('<img src="images/ajax-loader.gif">'); //menampilkan loading gambar
		$("#shopping-cart-results" ).load( "cart_process.php", {"load_cart":"1"}); //membuat permintaan ajax menggunakan dengan jQuery Load() & update
	});
	
	//keluar keranjang belanja
	$( ".close-shopping-cart-box").click(function(e){ //fungsi klik pengguna pada keranjang belanja
		e.preventDefault(); 
		$(".shopping-cart-box").fadeOut(); //keluar keranjang belanka
	});
	
	//Menghapus item dari keranjang
	$("#shopping-cart-results").on('click', 'a.remove-item', function(e) {
		e.preventDefault(); 
		var pcode = $(this).attr("data-code"); //mendapatkan get produk
		$(this).parent().fadeOut(); //menghapus elemen item dari kotak
		$.getJSON( "cart_process.php", {"remove_code":pcode} , function(data){ //mendapatkan Harga Barang dari Server
			$("#cart-info").html(data.items); //update Menjullahkan item pada cart-info
			$(".cart-box").trigger( "click" ); //trigger click on cart-box to untuk memperbarui daftar item
		});
	});

});
</script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
